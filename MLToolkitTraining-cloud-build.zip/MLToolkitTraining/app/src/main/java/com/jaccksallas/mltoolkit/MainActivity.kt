package com.jaccksallas.mltoolkit

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Button
import android.graphics.Typeface
import android.view.ViewGroup
import android.content.Context

class MainActivity : Activity() {
    private lateinit var arena: ArenaView
    private val bg = Color.rgb(10, 12, 16)
    private val panel = Color.rgb(21, 24, 31)
    private val accent = Color.rgb(0, 230, 160)
    private val muted = Color.rgb(150, 160, 174)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("ML TOOLKIT", 25f, Color.WHITE, true))
        content.addView(label("TRAINING SIMULATOR  •  NO ROOT", 11f, accent, true).apply {
            setPadding(0, dp(4), 0, dp(14))
        })

        val status = TextView(this).apply {
            text = "●  SIMULATION ACTIVE\nTarget data: local demo only"
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        content.addView(status, matchWrap())
        content.addView(label("ARENA PREVIEW", 13f, Color.WHITE, true).apply {
            setPadding(0, dp(18), 0, dp(8))
        })
        arena = ArenaView(this)
        content.addView(arena, LinearLayout.LayoutParams(-1, dp(300)))

        content.addView(label("VISUAL MODULES", 13f, Color.WHITE, true).apply {
            setPadding(0, dp(18), 0, dp(6))
        })
        addToggle(content, "Tracer", "Draw a line to each simulated target", true) { arena.tracer = it }
        addToggle(content, "ESP Box", "Outline the simulated target", true) { arena.box = it }
        addToggle(content, "Health Bar", "Show simulated target HP", true) { arena.health = it }
        addToggle(content, "Position Line", "Draw target direction guide", true) { arena.positionLine = it }

        val reset = Button(this).apply {
            text = "RESET SIMULATION"
            setTextColor(Color.BLACK)
            setBackgroundColor(accent)
            setOnClickListener { arena.resetTargets() }
        }
        content.addView(reset, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(16) })
        content.addView(label("This prototype does not connect to or read Mobile Legends game data.", 11f, muted, false).apply {
            setPadding(0, dp(12), 0, dp(8))
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addToggle(parent: LinearLayout, title: String, subtitle: String, initial: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(5), dp(8), dp(5))
            setBackgroundColor(panel)
        }
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        textCol.addView(label(title, 14f, Color.WHITE, true))
        textCol.addView(label(subtitle, 10f, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        val check = CheckBox(this).apply {
            isChecked = initial
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
        row.addView(textCol)
        row.addView(check)
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(3) }
        parent.addView(row, lp)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

private data class DemoTarget(var x: Float, var y: Float, var vx: Float, var vy: Float, var hp: Float, val name: String)

class ArenaView(context: Context) : View(context) {
    var tracer = true; set(value) { field = value; invalidate() }
    var box = true; set(value) { field = value; invalidate() }
    var health = true; set(value) { field = value; invalidate() }
    var positionLine = true; set(value) { field = value; invalidate() }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(15, 22, 27) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(33, 47, 51); strokeWidth = 1f }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 160); style = Paint.Style.STROKE; strokeWidth = 2.5f }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 75, 95); strokeWidth = 2f }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 190, 70); strokeWidth = 1.5f }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 12f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }
    private val hpBack = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(75, 28, 36) }
    private val hpFront = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 230, 130) }
    private val playerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(80, 160, 255) }
    private var lastFrame = System.nanoTime()
    private var targets = listOf(
        DemoTarget(.28f, .32f, .19f, .12f, .78f, "DEMO-01"),
        DemoTarget(.72f, .48f, -.13f, .17f, .46f, "DEMO-02"),
        DemoTarget(.53f, .72f, .15f, -.11f, .91f, "DEMO-03")
    )

    fun resetTargets() {
        targets = listOf(
            DemoTarget(.28f, .32f, .19f, .12f, .78f, "DEMO-01"),
            DemoTarget(.72f, .48f, -.13f, .17f, .46f, "DEMO-02"),
            DemoTarget(.53f, .72f, .15f, -.11f, .91f, "DEMO-03")
        )
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        canvas.drawRoundRect(RectF(0f, 0f, w, h), 18f, 18f, bgPaint)
        for (i in 1..5) canvas.drawLine(w * i / 6f, 0f, w * i / 6f, h, gridPaint)
        for (i in 1..5) canvas.drawLine(0f, h * i / 6f, w, h * i / 6f, gridPaint)
        val now = System.nanoTime()
        val dt = ((now - lastFrame) / 1_000_000_000f).coerceAtMost(.04f)
        lastFrame = now
        val anchorX = w * .5f; val anchorY = h * .88f
        canvas.drawCircle(anchorX, anchorY, 7f, playerPaint)
        canvas.drawText("YOU", anchorX - 12f, anchorY + 22f, textPaint)

        targets.forEach { t ->
            t.x += t.vx * dt; t.y += t.vy * dt
            if (t.x < .12f || t.x > .88f) t.vx *= -1
            if (t.y < .12f || t.y > .82f) t.vy *= -1
            t.hp -= dt * .012f
            if (t.hp < .18f) t.hp = .95f
            val cx = t.x * w; val cy = t.y * h
            val r = RectF(cx - 23f, cy - 31f, cx + 23f, cy + 31f)
            if (tracer) canvas.drawLine(anchorX, anchorY, cx, cy, linePaint)
            if (positionLine) {
                canvas.drawLine(cx, cy + 34f, cx, h - 14f, guidePaint)
                canvas.drawCircle(cx, cy, 3.5f, guidePaint)
            }
            if (box) canvas.drawRoundRect(r, 4f, 4f, boxPaint)
            if (health) {
                val hb = RectF(cx - 23f, cy - 43f, cx + 23f, cy - 37f)
                canvas.drawRoundRect(hb, 2f, 2f, hpBack)
                canvas.drawRoundRect(RectF(hb.left, hb.top, hb.left + hb.width() * t.hp, hb.bottom), 2f, 2f, hpFront)
            }
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText(t.name, cx, cy - 49f, textPaint)
            textPaint.textAlign = Paint.Align.LEFT
        }
        postInvalidateOnAnimation()
    }
}

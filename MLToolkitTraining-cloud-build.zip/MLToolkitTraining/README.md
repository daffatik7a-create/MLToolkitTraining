# ML Toolkit — Training Simulator

A Kotlin Android Studio starter project for a local visual training simulator. It draws simulated targets with toggles for Tracer, ESP Box, Health Bar, and Position Line. It does not read Mobile Legends memory, screen state, network traffic, or game data.

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this folder, then open `MLToolkitTraining` in Android Studio.
3. Allow Gradle sync to finish. Use JDK 17 if Android Studio asks for a Gradle JDK.
4. Connect an Android device with USB debugging enabled, or start an emulator.
5. Select **app** and press **Run**.
6. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio shows the output path after the build.

## Project structure
- `app/src/main/java/com/jaccksallas/mltoolkit/MainActivity.kt` — dark UI, module switches, and Canvas arena.
- `app/src/main/AndroidManifest.xml` — app entry point.
- `app/build.gradle.kts` — Android/Kotlin build configuration.

## Notes
- Minimum Android version: Android 6.0 (API 23).
- Compile SDK: 35.
- No root permission or special Android permission is needed for the simulator.
- Overlay-on-top permission is not included in this starter project.
